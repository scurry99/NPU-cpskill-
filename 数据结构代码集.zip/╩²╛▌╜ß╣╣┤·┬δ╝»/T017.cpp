#include<stdio.h>
#include<stdlib.h>
typedef struct Bitnode
{
	char data;
	struct Bitnode *leftchild,*rightchild;
}Bitnode,*Bitree;
void creat(Bitree &T)
{
	char c;
	scanf("%c",&c);
	if(c=='#')T=NULL;
	else
	{
		T=(Bitree)malloc(sizeof(Bitnode));
		T->data=c;
		creat(T->leftchild);
		creat(T->rightchild);
	}
}
void outPrintf(Bitree &T)
{
	if(T)
	{
		outPrintf(T->leftchild);
		printf("%c",T->data);
		
		outPrintf(T->rightchild);
	}
}
int main()
{
	Bitree T;
	creat(T);
	outPrintf(T);
	return 0;
}
