#include<stdio.h>
#define INF 10000
#define maxsize 100
int A[maxsize][maxsize];
typedef struct
{
	int no;
}Vexnode;
typedef struct
{
	int edges[maxsize][maxsize];
	int n,e;
	Vexnode vex[maxsize];
}Mgraph;
void creat(Mgraph &G)
{
	int i,j;
	scanf("%d",&G.n);
	for(i=0;i<G.n;++i)
		for(j=0;j<G.n;++j)
			scanf("%d",&G.edges[i][j]);
}
void Floyd(Mgraph &G,int A[][maxsize])
{
	int i,j,k;
	for(i=0;i<G.n;++i)
		for(j=0;j<G.n;++j)
			A[i][j]=G.edges[i][j];
	for(k=0;k<G.n;++k)
		for(i=0;i<G.n;++i)
			for(j=0;j<G.n;++j)
				if(A[i][j]>A[i][k]+A[k][j])A[i][j]=A[i][k]+A[k][j];
}
int main()
{
	int m,vi[maxsize],vj[maxsize];
	Mgraph G;
	creat(G);
	Floyd(G,A);
	scanf("%d",&m);
	for(int i=0;i<m;++i)scanf("%d%d",&vi[i],&vj[i]);
	for(int i=0;i<m;++i)printf("%d\n",A[vi[i]][vj[i]]);
	return 0;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
}

