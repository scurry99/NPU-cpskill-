#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct {
	unsigned int weight;
	unsigned int parent,lchild,rchild;
}HTnode,*Huffmantree;
typedef char **Huffmancode;
Huffmantree HT;
Huffmancode HC;
int min(Huffmantree t,int i)
 { 
   int j,m;
   unsigned int k=0xffffffff; 

   for(j=1;j<=i;j++) 
     if(t[j].weight<k&&t[j].parent==0) 
     { k=t[j].weight; 
       m=j; 
     }
   t[m].parent=1; 
   return m; 
 }

 void select(Huffmantree t,int i,int &s1,int &s2)
 { 
 
   int j;
 
   s1=min(t,i); 
   s2=min(t,i);
 
   if(t[s1].weight>t[s2].weight)
   {
     j=s1;
     s1=s2; 
     s2=j; 
   }
 }

void Huffmancoding(int *w,int n)
{
	int m,i,s1,s2;
	Huffmantree p;
	if(n<=1)return;
	m=2*n-1;
	HT=(Huffmantree)malloc((m+1)*sizeof(HTnode));
	for(p=HT+1,i=1;i<=n;++i,++p,++w)
	{
		(*p).weight=*w;
		(*p).parent=0;
		(*p).lchild=0;
		(*p).rchild=0;
	}
	for(;i<=m;++i,++p)(*p).parent=0;
	for(i=n+1;i<=m;++i)
	{
		select(HT,i-1,s1,s2);
		HT[s1].parent=HT[s2].parent=i;
		HT[i].lchild=s1;
		HT[i].rchild=s2;
		HT[i].weight=HT[s1].weight+HT[s2].weight;
	}
}
void  encoding(int n)
{
	int start,i;
   unsigned int f,c;
   char *cd;
   HC=(Huffmancode)malloc((n+1)*sizeof(char*));
   cd=(char*)malloc(n*sizeof(char));
   cd[n-1]='\0'; 
   
   for(i=1;i<=n;i++)   
   { 
     start=n-1; 
     for(c=i,f=HT[i].parent;f!=0;c=f,f=HT[f].parent) 
       {if(HT[f].lchild==c)
         cd[--start]='0'; 
       else 
         cd[--start]='1';
	 }
     HC[i]=(char*)malloc((n-start)*sizeof(char)); 
     strcpy(HC[i],&cd[start]); 
   }
   free(cd); 

}
int main()
{
	int sum,i,n,*w1;
	char tmp,c,*w2,*w3;
	scanf("%d",&n);
	w1=(int *)malloc(n*sizeof(int));
	w2=(char *)malloc(n*sizeof(char));
	w3=(char *)malloc(100*sizeof(char));
	for(i=0;i<n;++i){getchar();scanf("%c",&w2[i]);}
	for(i=0;i<n;++i)scanf("%d",&w1[i]);
	getchar();
	gets(w3);
	Huffmancoding(w1,n);
	encoding(n);
	sum=strlen(w3);
	for(i=0;i<sum;i++)
	{
		int j;
		tmp=w3[i];
		for(j=0;j<n;j++)if(w2[j]==tmp)break;
		printf("%s",HC[j+1]);
	}
	printf("\n");
	puts(w3);
	return 0;
}