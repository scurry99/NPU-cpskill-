#include<stdio.h>
#include<stdlib.h>
typedef struct lnode{
	int data;
	struct lnode *next;
}lnode,*link_list;
int main()
{
	link_list s,p;
	int i,elenum, a[1001];
	scanf("%d",&elenum);
	for(i=0;i<elenum;i++)scanf("%d",&a[i]);
	s=(link_list)malloc(elenum*sizeof(lnode));
	p=s;
	for(p=p+elenum-1;p>=s;p--){
		p->data=a[--i];
		printf("%d ",p->data );
	}
	printf("\n");
	for(i=elenum-1;i>=0;i--)printf("%d ",a[i]);
	printf("\n");
	free(s);
	return 0;
}