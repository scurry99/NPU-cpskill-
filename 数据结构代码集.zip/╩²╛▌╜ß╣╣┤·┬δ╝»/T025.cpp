#include<stdio.h>
#include<stdlib.h>
typedef struct Btnode
{
	int key;
	struct Btnode *lchild;
	struct Btnode *rchild;
}Btnode,*Btree;
void create_BST(Btree &BT,int key)
{
		if(BT==NULL)
	{
		BT=(Btnode*)malloc(sizeof(Btnode));
		BT->key=key;
		BT->lchild=BT->rchild=NULL;
	}
	else
	{
		if(BT->key==key)return;
		else if(BT->key>key)create_BST(BT->lchild,key);
		else create_BST(BT->rchild,key);
	}	
}
void xianxushuchu(Btree &BT,int key[],int a,int b)
{
	static int i=0;
	if(BT)
	{
		xianxushuchu(BT->lchild,key,a,b);
		if(BT->key>a&&BT->key<b)printf("%d ",BT->key);
		xianxushuchu(BT->rchild,key,a,b);
	}
}
void xian(Btree &BT)
{
	static int i=0;
	if(BT)
	{
		xian(BT->lchild);
		printf("%d ",BT->key);
		xian(BT->rchild);
	}
}
void xian1(Btree &BT,int seart_a)
{
	static int i=0;
	if(BT)
	{
		xian1(BT->lchild,seart_a);
		if(BT->key!=seart_a)printf("%d ",BT->key);
		xian1(BT->rchild,seart_a);
	}
}
void Delete(Btree &BT,int key)
{
	Btree q,s;
	if(!(BT->lchild))
	{
		q=BT;
		BT=BT->rchild;
		free(q);
	}
	else if(!(BT->rchild))
	{
		q=BT;
		BT=BT->lchild;
		free(q);
	}
	else
	{
		q=BT;
		s=BT->lchild;
		while(s->rchild)
		{
			q=s;s=s->rchild;
		}
		BT->key=s->key;
		if(q!=BT)q->rchild=s->lchild;
		else q->lchild=s->lchild;
		free(s);
	}
}
void DeleteBFS(Btree &BT,int key)
{
	if(!BT)return;
	else 
	{
		if(key==BT->key)Delete(BT,key);
		else if(key>BT->key)DeleteBFS(BT->rchild,key);
		else DeleteBFS(BT->lchild,key);
	}
}
int main()
{
	int a,b,seart_a,delete_b,temp,key[100];
	Btree BT;
	BT=NULL;
	do{scanf("%d",&temp);
	if(temp!=-1)create_BST(BT,temp);
	}while((getchar())!='\n');
	scanf("%d%d",&a,&b);
	scanf("%d%d",&seart_a,&delete_b);
	xianxushuchu(BT,key,a,b);
	printf("\n");
	create_BST(BT,seart_a);
	xian(BT);
	printf("\n");
	DeleteBFS(BT,delete_b);
	xian1(BT,seart_a);
	return 0;
}