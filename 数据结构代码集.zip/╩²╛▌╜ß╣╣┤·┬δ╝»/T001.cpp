#include<stdio.h>
void ins_link(int elenum,int *a,int ins_element)
{
	int t=-1,i;
	for(i=0;i<elenum;i++)
	{
		if(ins_element<a[i]){t=i;break;}
	}
	if(t==-1)a[elenum]=ins_element;
	else {
		for(i=elenum+1;i>t;i--)
	{
		a[i]=a[i-1];
	}
	a[t]=ins_element;
	}
}
int main()
{
	int ins_element,elenum,i,a[1001];
	scanf("%d",&elenum);
	for(i=0;i<elenum;i++)scanf("%d ",&a[i]);
	scanf("%d",&ins_element);
	ins_link(elenum,a,ins_element);
	for(i=0;i<elenum+1;i++)printf("%d ",a[i]);
	printf("\n");
	return 0;
}