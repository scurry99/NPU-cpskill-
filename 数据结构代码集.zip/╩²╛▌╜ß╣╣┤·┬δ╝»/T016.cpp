#include<stdio.h>
#include<stdlib.h>
typedef struct	Bitnode{
	char data;
	struct Bitnode *lchild,*rchild;
}Bitnode,*Bitree;
void creat(Bitree &T)
{
	char c;
		scanf("%c",&c);
		if(c=='#'){
			T=NULL;
		}
		else if(c>='A'&&c<='z'){
			T=(Bitree)malloc(sizeof(Bitnode));
			T->data=c;
			creat(T->lchild);
			creat(T->rchild);}
	
}
int preordertraverse(Bitree T)
{
	static int sum=0;
	if(T)
	{
		if(T->lchild==NULL&&T->rchild==NULL)sum++;
		preordertraverse(T->lchild);
		preordertraverse(T->rchild);
	}
	return sum;
}
int main()
{
	int  sum;
	Bitree T;
	creat(T);
	sum=preordertraverse(T);
	printf("%d",sum);
	return 0;
}
