#include<stdio.h>
int main()
{
	int max,k,i,t;
	scanf("%d%d",&max,&k);
	int A[1500];
	for(i=0;i<k-1;i++)
	{
		A[i]=0;
	}
	A[k-1]=1,A[k]=1;
	for(i=1;k+i<1500;i++)
	{
		A[k+i]=2*A[k+i-1]-A[i-1];
	}
	for(i=0;i<1500;i++)
	{
		if(A[i]<=max&&A[i+1]>=max)
		{
			t=i;
			break;
		}
		else continue;
	}
	for(i=t-k+1;i<=t;i++)
	{
		printf("%d ",A[i]);
	}
	return 0;
}
