#include<stdio.h>
int main()
{
	int i,j,k,n,m,a[20],b[20],c[40];
	scanf("%d",&n);
	for(i=0;i<n;i++)scanf("%d",&a[i]);
	scanf("%d",&m);
	for(i=0;i<m;i++)scanf("%d",&b[i]);
	i=0;j=0;k=0;
	while(i<n&&j<m)
	{
		if(a[i]<=b[j])
		{
			c[k++]=a[i];
			i++;
		}
		else
		{
			c[k++]=b[j];
			j++;
		}
	}
	if(i==n)
	{
		while(k<(n+m))c[k++]=b[j++];
	}
	else 
		{
			while(k<(n+m))c[k++]=a[i++];
	}
	for(i=0;i<n+m;i++)printf("%d\n",c[i]);
	return 0;
}