#include<stdio.h>
#include<malloc.h>
typedef struct DLNode
{
	struct DLNode *pre;
	struct DLNode *next;
	char data;
	int freq;
}DLNode,*DLinklist;
void creatlinklist(DLinklist &L,int m)
{
	DLinklist p1,p2;
	L=(DLinklist)malloc(sizeof(DLNode));
	p1=L;
	L->freq=0;
	for(int i=0;i<m;i++)
	{
		p2=(DLinklist)malloc(sizeof(DLNode));
		scanf(" %c",&(p2->data));
     	p2->freq=0;
		p2->pre=p1;
		p1->next=p2;
		p1=p2;
	}
	p1->next=L;
	L->pre=p1;
}
void locate(DLinklist &L,char x)
{
	DLinklist q,p=L->next;
	while(p!=L&&p->data!=x)p=p->next;
	if(p==L)return;
    p->freq+=1;q=p->pre;
	while(p->freq>q->freq&&q!=L)
	{
		p->pre=q->pre;
	q->next=p->next;
	q->pre->next=p;
	p->next->pre=q;
	q->pre=p;
	p->next=q;
	q=p->pre;
	}
}
void travellist(DLinklist L)
{
	DLinklist p;
	p=L->next;
	while(p!=L)
		{
			printf("%c ",p->data);
			p=p->next;
	}
}
int main()
{
	int i,m,n;
	char ch;
	DLinklist L;
	scanf("%d%d",&m,&n);
	getchar();
	creatlinklist(L,m);
	while(n>=1)
		{
			for(i=0;i<n;i++)
	{
		getchar();
		ch=getchar();
		locate(L,ch);
	}
			break;
	}
	travellist(L);
	printf("\n");
	return 0;
}