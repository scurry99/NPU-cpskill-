#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct Bitnode
{
	char data;
	struct Bitnode *leftchild,*rightchild;
}Bitnode,*Bitree;
void visit(char c,int i,int sum_b,char B[],char C[])
{
	static int n=0;
	int p;
	C[n++]=c;
	for(int m=0;m<sum_b;m++)if(B[m]==c){B[m]='!';p=m;}
	if(p==0)
	{C[n++]='#';
	if(B[p+1]=='!')C[n++]='#';
	}
	else if(p==sum_b-1)
	{C[n++]='#';
	if(B[p-1]=='!')C[n++]='#';
	}
	else if(B[p-1]=='!')
	{
		C[n++]='#';
		if(B[p+1]=='!')C[n++]='#';
	}
	else if(B[p+1]=='!')C[n++]='#';
	else return;
	
}
void create(Bitree &T,char c[])
{
	static int i=0;
	if(c[i]=='#'){T=NULL;i++;}
		else 
		{
			T=(Bitree)malloc(sizeof(Bitnode));
			T->data=c[i++];
			T->leftchild=T->rightchild=NULL;
			create(T->leftchild,c);
			create(T->rightchild,c);
		}
}
void print(Bitree &T)
{
	if(T)
	{
		print(T->leftchild);
		print(T->rightchild);
		printf("%c",T->data);
	}
}
int main()
{
	Bitree T;
	int sum_a=0,sum_b=0,sum_c=0;
	char A[100],B[100],c[200];
	gets(A);
	gets(B);
	sum_a=strlen(A);
	sum_b=strlen(B);
	for(int i=0;i<sum_a;i++)visit(A[i],i,sum_b,B,c);
	create(T,c);
	print(T);
	return 0;
}
