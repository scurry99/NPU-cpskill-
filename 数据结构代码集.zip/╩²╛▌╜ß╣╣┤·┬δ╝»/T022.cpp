#include<stdio.h>
#define INF 10000
#define maxsize 100
int dist[maxsize];
int path[maxsize];
typedef struct
{
	int no;
}Vexnode;
typedef struct 
{
	int data;
	int m;
}DATA;
typedef struct
{
	int edges[maxsize][maxsize];
	int n,e;
	Vexnode vex[maxsize];
}Mgraph;
void creat(Mgraph &G)
{
	int i,j,vi,vj,info;
	scanf("%d%d",&G.n,&G.e);
	for(i=1;i<=G.n;++i)
		for(j=1;j<=G.n;++j)
			G.edges[i][j]=INF;
	for(i=1;i<=G.n;++i)G.edges[i][i]=0;
	for(i=1;i<=G.e;++i)
	{
		scanf("%d%d%d",&vi,&vj,&info);
		G.edges[vi][vj]=info;
	}
}
void Dij(Mgraph &G,int v,int dist[],int path[])
{
	int set[maxsize];
	int min,i,j,u;
	for(i=1;i<=G.n;++i)
	{
		set[i]=0;
		dist[i]=G.edges[v][i];
		if(G.edges[v][i]<INF)path[i]=v;
		else path[i]=-1;
	}
	set[v]=1;
	path[v]=-1;
	for(i=0;i<G.n-1;++i)
	{
		min=INF;
		for(j=1;j<=G.n;++j)
		{
			if(set[j]==0&&dist[j]<min)
			{
				u=j;
				min=dist[j];
			}
		}
		set[u]=1;
		for(j=1;j<=G.n;++j)
		{
			if(set[j]==0&&dist[j]>dist[u]+G.edges[u][j])
			{
				dist[j]=dist[u]+G.edges[u][j];
				path[j]=u;
			}
		}
	}
}
void printMgraph(Mgraph &G,int v,DATA origdata[])
{
	DATA tmp;
	for(int j=1;j<G.n;j++)
	{
		for(int i=1;i<G.n-j;++i)
			if(origdata[i].data>origdata[i+1].data)
			{
				tmp=origdata[i];
				origdata[i]=origdata[i+1];
				origdata[i+1]=tmp;
			}
	}
	for(int i=1;i<=G.n;++i)
	{
		if(i!=1){
			if(origdata[i].data!=INF)printf("%d %d %d\n",v,origdata[i].m,origdata[i].data);
			else printf("%d %d %d\n",v,origdata[i].m,-1);
		}
	}
}
void  copydata(Mgraph &G,DATA origdata[],int dist[])
{
	for(int i=1;i<=G.n;++i)
		{
			origdata[i].data=dist[i];
			origdata[i].m=i;
	}
}
int main()
{
	Mgraph G;
	DATA origdata[maxsize];
	creat(G);
	Dij(G,1,dist,path);
	copydata(G,origdata,dist);
	printMgraph(G,1,origdata);
	return 0;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
}

