#include<stdio.h>
#include<string.h>
#define maxsize 100
void prexpression(char *e,int i)
{
	char stack1[maxsize],stack2[maxsize],*p=e,x;
	 int top1=-1,top2=-1;
	stack1[++top1]='#';
	for(;p<e+i;++p)
	{
		switch(*p)
		{
		case '(':stack1[++top1]=*p;break;
		case ')':while(stack1[top1]!='(')
				 {
					x=stack1[top1--];
					stack2[++top2]=x;
				 }
				 x=stack1[top1--];break;
		case '-':
		case '+':
			for(x=stack1[top1];x!='#';x=stack1[top1])
			{
				if(x=='(')break;
				else
				{
					x=stack1[top1--];
					stack2[++top2]=x;
				}
			}
			stack1[++top1]=*p;
			break;
			case '*':
			case '/':
				for(x=stack1[top1];x!='#'&&x!='+'&&x!='-';x=stack1[top1])
			{
				if(x=='(')break;
				else
				{
					x=stack1[top1--];
					stack2[++top2]=x;
				}
			}
			stack1[++top1]=*p;
			break;
			default :stack2[++top2]=*p;
		}
		
	}
	while(top1!=-1&&stack1[top1]!='#')
	{
			x=stack1[top1--];
			stack2[++top2]=x;
	}
	p=stack2;
	for(p=stack2;p<stack2+i-1;p++)printf("%c",*p);
}
int main()
{
	char ch,e[100];
	int i=0;
	while((ch=getchar())!='\n')e[i++]=ch;
	prexpression(e,i);
	return 0;
}