#include <stdio.h>
#include <stdlib.h>
#define MAX 1200
typedef struct DuLNode{
    int            data;
    struct DuLNode *first;
    struct DuLNode *last;
    struct DuLNode *prior;
    struct DuLNode *next;
   }DuLNode,*DuLinkList;      //����˫������
void InitLinkList(DuLNode **p)
{
    *p=(DuLinkList)malloc(sizeof(DuLNode));
	if(*p!=0)(*p)->next=(*p)->prior=*p;
}
void Create(DuLinkList L)
{
	DuLinkList p=L,q;
    int i;
    L->first=p;
	for(i=0;i<MAX;i++){
		q=(DuLinkList)malloc(sizeof(DuLNode));
		q->data=0;
		p->next=q;
		q->prior=p;
		q->next=NULL;
		p=q;
	}
	L->last=q;
}
void Jia(DuLinkList a,DuLinkList b)
{
	DuLinkList p=a->last,q=b->last;
	int x;
	while(q!=b->first)
	   {
		x=q->data+p->data;     //iλ����
		q->data=x%10;          //iλ�ĸ�λ
		q->prior->data+=x/10;  //��λ
		q=q->prior;
		p=p->prior;
	   }
}
void Cheng(DuLinkList a,int k)
{
	DuLinkList p=a->last;
	int x,y=0;
	for(;p!=a->first;p=p->prior)
        {
		x=(p->data)*k+y;//iλ����
		y=x/10;//��λ����
		p->data=x%10;//iλ�ĸ�λ
	    }
	    x=(p->data)*k+y;//iλ����
		y=x/10;//��λ����
		p->data=x%10;//iλ�ĸ�λ
}
void Chu(DuLinkList a,int k)
{
	DuLinkList p=a->first;
	int x,y=0;
	for(;p!=NULL;p=p->next)
	    {
		x=p->data+y*10;//��λ��
		p->data=x/k;//������
		y=x%k;//����
	    }
}
void Calculation(int n)
{
	int i,top=1,bottom=3,x=0;
	DuLinkList sum,num,l,p;
	InitLinkList(&sum);
	InitLinkList(&num);
	Create(sum);
	Create(num);
	num->first->data=1;
	l=num;
	while(x++<2000)
	    { 
       Cheng(num,top);
		Chu(num,bottom);
        Jia(num,sum);
		top++;bottom+=2;
        }
	Cheng(sum,2);
	printf("%d.",3);
        for(i=0;i<n;i++)
        {
        printf("%d",sum->next->data); //��ʮ��λ��ʼ��ӡ
        sum=sum->next;
        }
}
int main(){
	int n;
	scanf("%d",&n);
	Calculation(n);
	printf("\n");
	return 0;
}
