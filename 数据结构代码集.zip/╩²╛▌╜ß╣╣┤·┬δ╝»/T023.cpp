#include<stdio.h>
void create_hash(int Hash[11],int key[8])
{
	int m;
	for(int i=0;i<11;++i)Hash[i]=0;
	for(int i=0;i<8;++i)
	{
		m=(3*key[i])%11;
		if(Hash[m]==0)Hash[m]=key[i];
		else 
		{
			while(Hash[m]!=0)
				{
					if(m<10)++m;
					else m=0;
			}
			Hash[m]=key[i];
		}
	}
}
int ASL(int Hash[11],int key[8])
{
	int count=0,m;
	for(int i=0;i<8;++i)
	{
		m=(3*key[i])%11;
		if(Hash[m]==key[i])++count;
		else{
			while(Hash[m]!=key[i])
			{
				++count;
				if(m<10)++m;
				else m=0;
			}
			++count;
		}
		
	}
	return count/8;
}

int main()
{
	int A;
	int Hash[11];
	int key[8]={22,41,53,46,30,13,1,67};
	create_hash(Hash,key);
	A=ASL(Hash,key);
	printf("%d\n",A);
}