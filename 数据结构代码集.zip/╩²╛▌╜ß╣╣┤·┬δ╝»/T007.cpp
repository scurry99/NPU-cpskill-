#include<stdio.h>
#include<string.h>
int pipei(int A[],int stack[],int top,int num)
{
	int i;
	for(i=0;i<num;i++)
	{
		if(A[i]=='('||A[i]=='{'||A[i]=='[')
		{
			stack[++top]=A[i];
		}
		else if(A[i]==')'||A[i]=='}'||A[i]==']')
		{
			if(top==-1)return 0;
			--top;
		}
		else continue;
	}
	if(top==-1)return 1;
	else return 0;
}

int main()
{
	int i=0,A[100],flag;
	char ch;
	while((ch=getchar())!='\n')A[i++]=ch;
	
	int stack[100];
	int top;
	top=-1;
	flag=pipei(A,stack,top,i);
	if(flag==1)printf("%s\n","yes");
	else printf("%s\n","no");
	return 0;
}