#include<stdio.h>
#include<stdlib.h>
int visit[10];
typedef struct Arcnode
{
	int adjvex;
	struct Arcnode *nextarc;
}Arcnode;
typedef struct 
{
	int data;
	Arcnode *firstarc;
}Vnode;
typedef struct 
{
	Vnode adjlist[10];
	int n,e;/*n������������e��������*/
}Agraph; 
int getlocate(Agraph G,int v1)
{
	for(int i=1;i<=G.n;++i)
	{
		if(G.adjlist[i].data==v1)return i;
	}
	return 0;
}
void create(Agraph &G)
{
	Arcnode *p,*q;
	int i,j,v1,v2,adj1,adj2;/*v1��β��v2��ͷ*/
	scanf("%d%d",&G.n,&G.e);
	for(i=1;i<=G.n;++i)
	{
			scanf("%d",&G.adjlist[i].data);
			G.adjlist[i].firstarc=NULL;
	}
	for(i=1;i<=G.e;++i)
	{
		scanf("%d%d",&v1,&v2);
		adj1=getlocate(G,v1);
		adj2=getlocate(G,v2);
		if(G.adjlist[adj1].firstarc==NULL)
		{
			p=(Arcnode *)malloc(sizeof(Arcnode));
			G.adjlist[adj1].firstarc=p;
			q=G.adjlist[adj1].firstarc;
		}
		else
		{
			q=G.adjlist[adj1].firstarc;
			for(j=0;j<G.e;++j,q=q->nextarc)
			{
				if(q->nextarc==NULL)break;
			}
			p=(Arcnode *)malloc(sizeof(Arcnode));
			q->nextarc=p;
			q=q->nextarc;
		}
		q->adjvex=adj2;
		q->nextarc=NULL;
	}
}
void BFS(Agraph &G,int v1)
{
	Arcnode *p;
	int queue[10],front=0,rear=0,tmp;
	for(int m=1;m<G.n;++m)
	{
		visit[m]=0;
	}
	visit[v1]=1;
	rear=(rear+1)%10;
	queue[rear]=v1;
	while(front!=rear)
	{
		front=(front+1)%10;
		tmp=queue[front];
		p=G.adjlist[tmp].firstarc;
		while(p!=NULL)
		{
			if(visit[p->adjvex]==0)
			{
				visit[p->adjvex]=1;
				rear=(rear+1)%10;
				queue[rear]=p->adjvex;
			}
			p=p->nextarc;
		}
	}

}
int BFStrave(Agraph &G,int i,int j)
{
	int m;
	for(m=1;m<=G.n;++m)
	{
		visit[m]=0;
	}
	BFS(G,i);
	if(visit[j]==1)return 1;
	else return 0;
}
int main()
{
	int i,j,end;
	Agraph G;
	create(G);
	scanf("%d%d",&i,&j);
	end=BFStrave(G,i,j);
	if(end==1)printf("%s\n","yes");
	else printf("%s\n","no");
}
