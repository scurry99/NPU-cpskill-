#include<stdio.h>
#include<stdlib.h>
int main()
{
	int n,k,m,*A,i,temp1,temp2;
	scanf("%d%d",&n,&k);
	A=(int *)malloc(sizeof(int)*(n+1));
	for(i=0;i<n;i++)scanf("%d",&A[i]);
	temp1=A[n-1-k];
	temp2=A[n-k];
	do{
		for(i=n;i>0;i--)A[i]=A[i-1];
		A[0]=A[n];
	}while(!(A[n-1]==temp1&&A[0]==temp2));
	for(i=0;i<n;i++)printf("%d ",A[i]);
	printf("\n");
	return 0;
}

