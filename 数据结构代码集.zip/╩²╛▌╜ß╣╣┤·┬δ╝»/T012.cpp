 #include<stdio.h>
#include<stdlib.h>
struct GPnode
{
	int a, b, c;
};
GPnode *B, *C, *D;
int i, t1, t2, t, s;
void search();
int main()
{
	int j, k;
	int a, b, c;
	GPnode A;
	scanf("%d %d", &t1, &t2);
	if (t1 > 0 && t1 < 100 && t2>0 && t2 < 100)
	{
		B = (GPnode*)malloc(t1 * sizeof(GPnode));
		C = (GPnode*)malloc(t2 * sizeof(GPnode));
		D = (GPnode*)malloc((t1 + t2) * sizeof(GPnode));
		j = 0;
		for (i = 0; i < t1; i++)
		{
			scanf("%d%d%d", &a, &b, &c);
			if (a > 0 && a < 100 && b>0 && b < 100)
			{
				B[j].a = a;
				B[j].b = b;
				B[j].c = c;
				D[j].a = B[j].a;
				D[j].b = B[j].b;
				D[j].c = B[j].c;
				j++;
			}
		}
		t = j;
		s = 0;
		for (i = 0; i < t2; i++)
		{
			scanf("%d%d%d", &a, &b, &c);
			if (a > 0 && a < 100 && b>0 && b < 100)
			{
				C[s].a = a;
				C[s].b = b;
				C[s].c = c;
				search();
				s++;
			}
		}
		for (i = 0; i < t - 1; i++)
		{
			k = i;
			for (j = i + 1; j < t; j++)
			{
				if (D[k].a > D[j].a)
				{
					k = j;
				}
				else if (D[k].a == D[j].a)
				{
					if (D[k].b > D[j].b)
					{
						k = j;
					}
				}
			}
			if (k != i)
			{
				A = D[k];
				D[k] = D[i];
				D[i] = A;
			}
		}
		for (i = 0; i < t; i++)
		{
			if (D[i].c != 0)
			{
				if (i == t - 1)
				{
					printf("%d %d %d\n", D[i].a, D[i].b, D[i].c);
				}
				else
				{
					printf("%d %d %d\n", D[i].a, D[i].b, D[i].c);
				}
			}
		}
	}
	return(0);
}
void search()
{
	int j, flag = 0;
	for (j = 0; j < t1; j++)
	{
		if (C[s].a == B[j].a&&C[s].b == B[j].b)
		{
			D[j].c += C[s].c;
			flag = 1;
			break;
		}
	}
	if (flag == 0)
	{
		D[t].a = C[s].a;
		D[t].b = C[s].b;
		D[t].c = C[s].c;
		t++;
	}
}
