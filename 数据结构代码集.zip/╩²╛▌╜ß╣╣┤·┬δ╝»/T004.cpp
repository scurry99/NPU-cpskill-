#include<stdio.h>
#include<stdlib.h>
typedef struct lnode{
	int data;
	struct lnode *next;
}lnode,*link_list;
void createlist_L(link_list &l,int number)
{
	l=(link_list)malloc(sizeof(lnode));
	l->next=NULL;
	link_list p2;
	link_list p1 = l;
	for(int i=0;i<number;i++)
	{
		p2=(link_list)malloc(sizeof(lnode));
		scanf("%d",&p2->data);
		p1->next=p2;
		p1=p2;
	}
	   p1->next = NULL;
}
void mergelist_L(link_list &A,link_list &B,link_list &C)
{
	link_list pa,pb,pc;
	pa=A->next;
	pb=B->next;
	C=pc=A;
	while(pa&&pb)
	{
		if(pa->data<=pb->data)
		{
			pc->next=pa;
			pc=pa;
			pa=pa->next;
		}
		else 
		{
			pc->next=pb;
			pc=pb;
			pb=pb->next;
		}
	}
	pc->next=pa?pa:pb;
	free(B);
}

void reprintlink(link_list &p)//�ݹ����������very good
{
    if(p==NULL)
    {
      return;
    }
    reprintlink(p->next);
    printf("%d ",p->data);
}
int main()
{
	int m,n;
	scanf("%d %d",&m,&n);
	link_list A,B,C,p;
	createlist_L(A,m);
	createlist_L(B,n);
	mergelist_L(A,B,C);
	p=A->next;
	reprintlink(p);
	printf("\n");
	return 0;
}