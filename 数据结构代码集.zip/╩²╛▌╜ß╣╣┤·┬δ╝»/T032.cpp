#include<stdio.h>
int getvalue(int TEMP[][3],int m,int n,int sum)
{
	int k=0;
	while(k<(sum-1)&&(TEMP[k][0]!=m+1||TEMP[k][1]!=n+1))k++;
	if(k<(sum-1))return TEMP[k][2];
	else return 0;
}
void cheng(int A[][3],int B[][3],int C[][3],int m,int n,int k,int sum1,int sum2)
{
	int i,j,l,s,p=0;
	for(i=0;i<m;i++)
		{
			for(j=0;j<k;j++)
			{
			s=0;
			for(l=0;l<n;l++)s+=getvalue(A,i,l,sum1)*getvalue(B,l,j,sum2);
			if(s!=0)
			{
			C[p][0]=i;
			C[p][1]=j;
			C[p][2]=s;
			p++;
			}
			}
	}
	C[p][2]=0;
}

void print(int C[][3])
{
		for(int i=0;C[i][2]!=0;i++)printf("%d %d %d\n",C[i][0]+1,C[i][1]+1,C[i][2]);
}
int main()
{
	int i,m,n,sum_a=0,sum_b=0,k,A[100][3],B[100][3],C[100][3];
	scanf("%d%d",&m,&n);
	for(i=0;;i++)
	{
  		scanf("%d%d%d",&A[i][0],&A[i][1],&A[i][2]);
		sum_a++;
		if(A[i][0]==0&&A[i][1]==0&&A[i][2]==0)break;
	}
	scanf("%d%d",&n,&k);
	for(i=0;;i++)
	{
		scanf("%d%d%d",&B[i][0],&B[i][1],&B[i][2]);
		sum_b++;
		if(B[i][0]==0&&B[i][1]==0&&B[i][2]==0)break;
	}
	cheng(A,B,C,m,n,k,sum_a,sum_b);
	print(C);
	return 0;
}