#include<stdio.h>
#include<stdlib.h>
typedef struct Lnode
{
	int data;
	struct Lnode *next;
}Lnode,*linklist;
void creatlist_L(linklist &L,int number)
{
	L=(linklist)malloc(sizeof(Lnode));
	L->next=NULL;
	linklist l,p;
	l=L;
	for(int i=0;i<number;i++)
	{
		p=(linklist)malloc(sizeof(Lnode));/*�����㣺Ӧ������ӵ����ӳ���*/
		scanf("%d",&p->data);
		l->next=p;
		l=p;
	}
	l->next=NULL;
}
void and_L(linklist &L1,linklist &L2,linklist &temp_L)
{
	temp_L=(linklist)malloc(sizeof(Lnode));
	temp_L->next=NULL;
	linklist p1,p2,p3,p;
	p1=L1->next;
	p2=L2->next;
	p3=temp_L;
	while(p1&&p2)
	{
		if(p1->data<p2->data)p1=p1->next;
		else if(p1->data==p2->data)
		{
			p=(linklist)malloc(sizeof(Lnode));
			p->data=p1->data;
			p3->next=p;
			p3=p;
			p1=p1->next;
		}
		else p2=p2->next;
	}
	p3->next=NULL;
	free(L1);
	free(L2);
}
void Printf(linklist &A)
{
	linklist p=A->next;
	while(p)
	{
		printf("%d ",p->data);
		p=p->next;/*�м�Ҫ�ƶ�p��λ��*/
	}
	printf("\n");
}
void Delete_L(linklist &A,linklist &B)
{
	linklist head=A,p1,p2;
	for(p2=B->next;p2!=NULL;p2=p2->next)
	{
		int i=p2->data;		
		head=A;/*�����ÿ�ε�ͷ��㸳ֵ��head*/
		for(p1=head->next;p1!=NULL;p1=head->next)
		{
			if(p1->data==i)
			{
				head->next=head->next->next;
				free(p1);
			}
			else head=head->next;
		}

	}
	head->next=NULL;
}
int main()
{
	int m,n,p;
	scanf("%d%d%d",&m,&n,&p);
	linklist A,B,C,temp_L;
	creatlist_L(A,m);
	creatlist_L(B,n);
	creatlist_L(C,p);
	and_L(B,C,temp_L);
	Delete_L(A,temp_L);
	Printf(A);
	return 0;
}