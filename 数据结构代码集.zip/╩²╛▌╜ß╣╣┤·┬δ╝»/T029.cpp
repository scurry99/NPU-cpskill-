#include<stdio.h>
int main()
{
	int sum=0,row,col,i,m,n,a[500][3];
	scanf("%d%d",&m,&n);
	for(i=0;;i++)
	{
		scanf("%d%d%d",&a[i][0],&a[i][1],&a[i][2]);
		sum++;
		if(a[i][0]==0&&a[i][1]==0&&a[i][2]==0)break;
	}
	for(col=0;col<n;col++)
	{
		for(row=0;row<m;row++)
		{
			if(a[row][1]==col)printf("%d %d %d\n",a[row][1],a[row][0],a[row][2]);
		}
	}
	return 0;
}