#include<stdio.h>
#define INF 10000
#define maxsize 100
int dist[maxsize];
int path[maxsize];
typedef struct
{
	int no;
}Vexnode;
typedef struct
{
	int edges[maxsize][maxsize];
	int n,e;
	Vexnode vex[maxsize];
}Mgraph;
void creat(Mgraph &G)
{
	int i,j;
	scanf("%d",&G.n);
	for(i=1;i<=G.n;++i)
		for(j=1;j<=G.n;++j)
			scanf("%d",&G.edges[i][j]);
}

void Dij(Mgraph &G,int v,int dist[],int path[])
{
	int set[maxsize];
	int min,i,j,u;
	for(i=1;i<=G.n;++i)
	{
		set[i]=0;
		dist[i]=G.edges[v][i];
		if(G.edges[v][i]<INF)path[i]=v;
		else path[i]=-1;
	}
	set[v]=1;
	path[v]=-1;
	for(i=0;i<G.n-1;++i)
	{
		min=INF;
		for(j=1;j<=G.n;++j)
		{
			if(set[j]==0&&dist[j]<min)
			{
				u=j;
				min=dist[j];
			}
		}
		set[u]=1;
		for(j=1;j<=G.n;++j)
		{
			if(set[j]==0&&dist[j]>dist[u]+G.edges[u][j])
			{
				dist[j]=dist[u]+G.edges[u][j];
				path[j]=u;
			}
		}
	}
}
void printpath(Mgraph G,int dist[])
{
	for(int i=1;i<=G.n;++i)printf("%d\n",dist[i]);
}
int main()
{
	Mgraph G;
	creat(G);
	Dij(G,1,dist,path);
	printpath(G,dist);
	return 0;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
}

