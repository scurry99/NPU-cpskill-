#include<stdio.h>
#include<stdlib.h>
typedef struct Btnode
{
	int key;
	struct Btnode *lchild;
	struct Btnode *rchild;
}Btnode,*Btree;
void create_BST(Btree &BT,int key)
{
	if(key!=-1)
	{
		if(BT==NULL)
	{
		BT=(Btnode*)malloc(sizeof(Btnode));
		BT->key=key;
		BT->lchild=BT->rchild=NULL;
	}
	else
	{
		if(BT->key==key)return;
		else if(BT->key>key)create_BST(BT->lchild,key);
		else create_BST(BT->rchild,key);
		}
	}
	
}
void xianxushuchu(Btree &BT,int key[])
{
	static int i=0;
	if(BT)
	{
		xianxushuchu(BT->lchild,key);
		key[i++]=BT->key;
		xianxushuchu(BT->rchild,key);
	}
}
void judge_BTS(int key[])
{
	for(int i=0;key[i+1]!=-1;++i)if(key[i]>key[i+1]){printf("%s\n","no");return ;}
	printf("%s\n","yes");
}
int main()
{
	int temp,key[100];
	Btree BT;
	BT=NULL;
	do{scanf("%d",&temp);
	create_BST(BT,temp);
	}while((getchar())!='\n');
	for(int i=0;i<100;++i)key[i]=-1;
	xianxushuchu(BT,key);
	judge_BTS(key);
	return 0;
}