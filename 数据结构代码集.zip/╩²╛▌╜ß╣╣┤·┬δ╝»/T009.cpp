#include<stdio.h>
#include<string.h>
typedef struct
{
	int data[100];
	int front;
	int rear;
}Squeue;
void initSqueue(Squeue &qu)
{
	qu.front=qu.rear=0;
}
void enSqueue(Squeue &qu,int x,int N)
{
	if((qu.rear+1)%N==qu.front)return ;
	qu.rear=(qu.rear+1)%N;
	qu.data[qu.rear]=x;
}

void de_qu(Squeue &qu,int x,int N)
{
	while(qu.data[qu.front+1]!=x)
	{
		if(qu.rear==qu.front)return ;
		qu.front=(qu.front+1)%N;
	}
	qu.front=(qu.front+1)%N;
}
void printf_qu(Squeue &qu,int N)
{
	int temp=qu.data[qu.front+1];
	if(qu.rear==qu.front)
	{printf("%s\n","there is no data in the queue");return ;}
	for(;qu.front!=qu.rear;qu.front=(qu.front+1)%N)printf("%d ",qu.data[qu.front+1]);
	printf("\n");                            
	printf("%d\n",temp);
}
void isfull(Squeue &qu,int N)
{
	if((qu.rear+1)%N==qu.front)printf("%s","yes");
	else printf("%s","no");
}
int main()
{
	int i=0,N,temp1,temp2;
	scanf("%d",&N);
	Squeue qu;
	initSqueue(qu);
	do{
		 i++;
		scanf("%d",&temp1);
		enSqueue(qu,temp1,N+1);
	}while(getchar()!='\n');
	isfull(qu,N+1);
	scanf("%d",&temp2);
	de_qu(qu,temp2,N+1);
	printf_qu(qu,N+1);
	return 0;
}