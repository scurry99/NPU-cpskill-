#include<stdio.h>
int  Union(int *B,int n,int *C,int p,int *D)
{
	int i,j,k=0,temp;
	for(i=0;i<n;i++)
	{
		temp=B[i];
		for(j=0;j<p;j++)
		{
			if(C[j]==temp){D[k++]=temp;break;}
		}
	}
	return k;
}
int Delete_link(int *A,int m,int *D,int D_sum,int *E)
{
	int k=0,j,i,temp;
	for(i=0;i<m;i++)
	{
		temp=A[i];
		for(j=0;j<D_sum;j++)
		{
			if(D[j]==temp)break;
		}
		if(j==D_sum)E[k++]=temp;
	}
	return k;
}
	

int main()
{
	int D_sum,E_sum,i,m,n,p,A[100],B[100],C[100],D[100],E[100];
	scanf("%d%d%d",&m,&n,&p);
	for(i=0;i<m;i++)
	{
		scanf("%d",&A[i]);
	}
		for(i=0;i<n;i++)
	{
		scanf("%d",&B[i]);
	}
		for(i=0;i<p;i++)
	{
		scanf("%d",&C[i]);
	}
	D_sum=Union(B,n,C,p,D);/*��B,C�Ĳ�������ֵ��D*/
	E_sum=Delete_link(A,m,D,D_sum,E);/*��A��ɾ��D��Ԫ�ز���ֵ��E*/
	for(i=0;i<E_sum;i++)printf("%d ",E[i]);
	printf("\n");
	return 0;
}
