#include<stdio.h>
#include<stdlib.h>
typedef struct Btnode
{
	int key;
	struct Btnode *lchild;
	struct Btnode *rchild;
}Btnode,*Btree;
void create_BST(Btree &BT,int key)
{
		if(BT==NULL)
	{
		BT=(Btnode*)malloc(sizeof(Btnode));
		BT->key=key;
		BT->lchild=BT->rchild=NULL;
	}
	else
	{
		if(BT->key==key)return;
		else if(BT->key>key)create_BST(BT->lchild,key);
		else create_BST(BT->rchild,key);
		}

	
}
void xianxushuchu(Btree &BT,int key[])
{
	static int i=0;
	if(BT)
	{
		xianxushuchu(BT->lchild,key);
		printf("%d ",BT->key);
		xianxushuchu(BT->rchild,key);
	}
}
int main()
{
	int temp,key[100];
	Btree BT;
	BT=NULL;
	do{scanf("%d",&temp);
	if(temp!=-1)create_BST(BT,temp);
	}while((getchar())!='\n');
	do{scanf("%d",&temp);
	if(temp!=-1)create_BST(BT,temp);
	}while((getchar())!='\n');
	for(int i=0;i<100;++i)key[i]=-1;
	xianxushuchu(BT,key);
	return 0;
}