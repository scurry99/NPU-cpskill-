#include<stdio.h>
#include<stdlib.h>
#define Maxsize 100
typedef struct Btnode
{
	int data;
	struct Btnode *lchild,*rchild;

}Btnode,*Bitree;
void creat(Bitree &T,int c,int sum)
{
	int flag=0,front=0,rear=0;
	Bitree temp,queue[Maxsize];
	T=(Bitree)malloc(sizeof(Btnode));
	T->data=c;
	T->lchild=T->rchild=NULL;
	flag+=1;
	rear=(rear+1)%Maxsize;
	queue[rear]=T;
	while(front!=rear)
	{
		front=(front+1)%Maxsize;
		temp=queue[front];
		scanf("%d%d",&temp->lchild->data,&temp->rchild->data);
		flag+=2;
		rear=(rear+1)%Maxsize;
		queue[rear]=temp->lchild;
		rear=(rear+1)%Maxsize;
		queue[rear]=temp->rchild;
		if(flag==sum)break;
	}
}
void preordertraverse(Bitree T)
{
	if(T)


	{
		printf("%c",T->data);
		preordertraverse(T->lchild);
		preordertraverse(T->rchild);
	}
}
